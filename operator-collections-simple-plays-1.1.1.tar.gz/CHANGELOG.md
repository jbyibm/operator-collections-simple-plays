## [1.1.0](https://github.ibm.com/operator-collections/simple-plays/compare/1.0.7...1.1.0) (2021-07-22)


### Features

* Add discovery and day 2 playbooks ([118bfbe](https://github.ibm.com/operator-collections/simple-plays/commit/118bfbec07592b93610462f7ea8796f954d3550f))

### [1.0.7](https://github.ibm.com/operator-collections/simple-plays/compare/1.0.6...1.0.7) (2021-07-21)

### [1.0.6](https://github.ibm.com/operator-collections/simple-plays/compare/1.0.5...1.0.6) (2021-07-16)


### Fixes

* bring back inventoryName ([6834c03](https://github.ibm.com/operator-collections/simple-plays/commit/6834c035b9f76e5cc42fb1e55de70730c4e2b824))

### [1.0.5](https://github.ibm.com/operator-collections/simple-plays/compare/1.0.4...1.0.5) (2021-07-16)


### Fixes

* remove inventoryName from operator-config ([277b742](https://github.ibm.com/operator-collections/simple-plays/commit/277b742df58c89295522d74776aa5e531017bf5c))

### [1.0.4](https://github.ibm.com/operator-collections/simple-plays/compare/1.0.3...1.0.4) (2021-07-16)


### Fixes

* Delete the file in the correct path ([a4d9d31](https://github.ibm.com/operator-collections/simple-plays/commit/a4d9d319b337c8027e0b63d67dcef4c940b3b2e1))

### [1.0.3](https://github.ibm.com/operator-collections/simple-plays/compare/1.0.2...1.0.3) (2021-07-16)


### Fixes

* restrict files to /tmp/zoscb/simple-plays folder ([077406d](https://github.ibm.com/operator-collections/simple-plays/commit/077406d094bbae934873e10ed5ffdd9baf653c8a))

### [1.0.2](https://github.ibm.com/operator-collections/simple-plays/compare/1.0.1...1.0.2) (2021-06-25)


### Build Changes

* test foo update in README ([035a915](https://github.ibm.com/operator-collections/simple-plays/commit/035a9153a9d76cf5c088e5a9041da7d88b3286c8))

### [1.0.1](https://github.ibm.com/operator-collections/simple-plays/compare/1.0.0...1.0.1) (2021-06-25)


### Doc Updates

* Update README with build status ([508583b](https://github.ibm.com/operator-collections/simple-plays/commit/508583b6c432827c733d66b06685a94913ce829e))

## 1.0.0 (2021-06-24)


### ⚠ BREAKING CHANGES

* Intiial release

### Features

* Intiial release ([76a3da8](https://github.ibm.com/operator-collections/simple-plays/commit/76a3da8e5930e74f08fad598368fe6e23519f092))


### Build Changes

* disable changelog for initial release ([0fae039](https://github.ibm.com/operator-collections/simple-plays/commit/0fae039f5c493f0ca465f75540b8b09c374df7ad))
* re-enable changelog ([0a77845](https://github.ibm.com/operator-collections/simple-plays/commit/0a77845185994e72b1d17694b16f3c0760c9727b))

